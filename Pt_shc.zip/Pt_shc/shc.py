#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
from scipy import linalg as la
import sisl as si
import matplotlib.pyplot as plt
from scipy.constants import physical_constants
import logging
from sisl import *

sile = si.get_sile('lead.fdf')
geom = sile.read_geometry()
H = sile.read_hamiltonian(geometry=geom)

H1   = H.Hk([0,0,0],format='array') # evaluating Hk at G just to obtain the total number of orbitals
Msize= int(np.sqrt(H1.size))

### Spin Hall Conductivity
from concurrent.futures import ProcessPoolExecutor

s_x = np.array([[0, 1],
                [1, 0]])
s_y = np.array([[0, -1j],
                [1j, 0]])
s_z = np.array([[1, 0],
                [0, -1]])

Lz_total = np.kron(np.eye(15),s_z) # Spin operator for 15 orbitals taking intou account a DZP basis

def fd(E, mu):  # FD distribution at T=0
    a = np.zeros((len(E)),dtype=float)
    for ik,ie in enumerate(E):
        if ie <= mu:
            a[ik] = 1.0
        else:
            a[ik] = 0.
    return a

gamma = 1.e-2  # small real number for broadening

def W(k):
    dHdx = H.dHk(k)[0]
    dHdy = H.dHk(k)[1]
    eigenValues, eigenVectors = H.eigh(k,eigvals_only=False)
    dSdx = H.dSk(k,format='array')[0]
    dSdy = H.dSk(k,format='array')[1]
    w = eigenValues #[idx]
    v = eigenVectors #[:,idx]

    vox1 = (dSdx).dot(v)
    vox  = v.conj().T.dot(vox1)
    voy1 = (0.5*((dSdy)@(Lz_total)+(Lz_total)@(dSdy))).dot(v)
    voy  = v.conj().T.dot(voy1)
    for i in range(Msize):
        vox[i,:] = vox[i,:]*w[i]
        voy[i,:] = voy[i,:]*w[i]

    vx1 = (dHdx).dot(v)
    vx  = v.conj().T.dot(vx1)
    vy1 = (0.5*((dHdy)@(Lz_total)+(Lz_total)@(dHdy))).dot(v)
    vy  = v.conj().T.dot(vy1)

    return vx-vox,vy-voy,w.real

bz = MonkhorstPack(H,[35,35,35],trs=False) # BZ sampling
len_k = len(bz.k)

def gen_curv(klist):  # in order to simplify the calculation, this generates all the matrices for the BZ mesh using pool, equivalent to BZ average in sisl
    k = bz.k[klist]
    vx,vy,energy_calc = W(k)
    return vx,vy,energy_calc

with ProcessPoolExecutor(max_workers=35) as executor:
    dens = list(executor.map(gen_curv, range(len_k)))

vsx = np.zeros((len_k,Msize,Msize),dtype=complex) # defining matrices for storing v and j_s matrices along with energy
vsy = np.zeros((len_k,Msize,Msize),dtype=complex)
eni = np.zeros((len_k,Msize),dtype=float)

for ik, k in enumerate(bz): # converting list from processpool into arrays for carrying out the calculation in the BZ 
    vsx[ik] = dens[ik][0]
    vsy[ik] = dens[ik][1]
    eni[ik] = dens[ik][2]

def spin_conductance(e):
    f_nm = np.zeros((len(bz),Msize,Msize), dtype=float)
    for i in range(Msize):
        for j in range(Msize):
            if (j != i):
                f_nm[:,i,j] += -1*np.imag(vsx[:,j,i]*vsy[:,i,j])/((eni[:,j]-eni[:,i])**2+gamma**2)*(fd(eni[:,i],e)-fd(eni[:,j],e))
    # in standard units (\hbar/e S/cm)
    return -1*np.sum(f_nm.real)/len_k/geom.volume*10**4

ene = np.linspace(-10,5,251)

with ProcessPoolExecutor(max_workers=35) as executor:
    shc = list(executor.map(spin_conductance, ene))

for i in zip(ene,shc):
    print(i[0],i[1])
