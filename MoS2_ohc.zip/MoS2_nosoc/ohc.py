#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
from scipy import linalg as la
import sisl as si
import matplotlib.pyplot as plt
from scipy.constants import physical_constants
import logging
from sisl import *

sile = si.get_sile('lead.fdf')
geom = sile.read_geometry()
H = sile.read_hamiltonian(geometry=geom)

H1   = H.Hk([0,0,0],format='array') # getting full matrix size
Msize= int(np.sqrt(H1.size))

from scipy.linalg import block_diag

# defining L matrices for p and d states according the order given in .ORB_INDX
L_px = np.array([[0,1.j,0],[-1.j,0.,0],[0,0.,0.]])
L_py = np.array([[0,0,0],[0.,0.,1.j],[0,-1.j,0]])
L_pz = np.array([[0,0.,1.j],[0.,0.,0.],[-1.j,0.,0.]])*0  # neglecting p states reproduces the results in the bibliography using Wannier functions https://doi.org/10.1103/PhysRevLett.126.056601

L_dx = np.array([[0,0,0,-1.j,0],[0,0,np.sqrt(3)*(-1.j),0,-1.j],[0,np.sqrt(3)*(1.j),0,0,0],[1.j,0,0,0,0],[0,1.j,0,0,0]])
L_dy = np.array([[0,1.j,0,0,0],[-1.j,0,0,0,0],[0,0,0,np.sqrt(3)*(-1.j),0],[0,0,np.sqrt(3)*(1.j),0,-1.j],[0,0,0,1.j,0]])
L_dz = np.array([[0,0,0,0,2.j],[0,0,0,1.j,0],[0,0,0,0,0],[0,-1.j,0,0,0],[-2.j,0,0,0,0]])

Mo_z=block_diag(0,0,L_dz,L_dz,L_pz)
S_z =block_diag(0,0,L_pz,L_pz,L_dz)

Mo_sz = np.kron(Mo_z,np.identity(1)) # creating atomic orbital matrices and '1' should be replace by '2' when there's SOC
S_sz  = np.kron(S_z ,np.identity(1))

Sz_total = block_diag(Mo_z,S_z,S_z) # full L operator enetering at the kubo formula

from concurrent.futures import ProcessPoolExecutor

delta_derivative = 0.75

def fd(E, mu):
    a = np.zeros((len(E)),dtype=float)
    for ik,ie in enumerate(E):
        if ie <= mu:
            a[ik] = 1.0
        else:
            a[ik] = 0.
    return a

def braket(bra, ket, op=None):
    if op is None:
        return bra.T.conj() @ ket
    return bra.T.conj() @ (op @ ket)

gamma = 5e-2  # small value for broadening

def W(k):
    dH   = H.dHk(k)
    dHdx = dH[0]
    dHdy = dH[1]
    w,v  = H.eigh(k,eigvals_only=False)
    dS   = H.dSk(k,format='array')
    dSdx = dS[0]
    dSdy = dS[1]

    vox1 = (dSdx).dot(v)
    vox  = v.conj().T.dot(vox1)
    voy1 = (dSdy@Sz_total+Sz_total@dSdy).dot(v)
    voy  = v.conj().T.dot(voy1)
    for i in range(Msize):
        vox[i,:] = vox[i,:]*w[i]
        voy[i,:] = vox[i,:]*w[i]

    vx1 = (dHdx).dot(v)
    vx  = v.conj().T.dot(vx1)

    vy1 = (dHdy@Sz_total+Sz_total@dHdy).dot(v)
    vy  = v.conj().T.dot(vy1)

    return vx-vox,vy-voy,w.real

bz = MonkhorstPack(H,[45,45,1],trs=False)
len_k = len(bz.k)

def gen_curv(klist):
    k = bz.k[klist]
    vx,vy,energy_calc = W(k)
    return vx,vy,energy_calc

with ProcessPoolExecutor(max_workers=24) as executor:
    dens = list(executor.map(gen_curv, range(len_k)))

vsx = np.zeros((len_k,Msize,Msize),dtype=complex)
vsy = np.zeros((len_k,Msize,Msize),dtype=complex)
eni = np.zeros((len_k,Msize),dtype=float)

for ik, k in enumerate(bz):
    vsx[ik] = dens[ik][0]
    vsy[ik] = dens[ik][1]
    eni[ik] = dens[ik][2]

def orbi_conductance(e):
    f_nm = np.zeros((len(bz),Msize), dtype=float)
    for i in range(Msize):
        for j in range(Msize):
            if (j != i):
                f_nm[:,i] += -1*np.imag(vsx[:,j,i]*vsy[:,i,j])/((eni[:,j]-eni[:,i])**2+gamma**2)*(fd(eni[:,i],e)-fd(eni[:,j],e))
    # in e/2pi units, it needs to be multiply by the z component of the lattice vectors since there's no periodicity along z
    return -1*np.sum(f_nm.real)/len_k/geom.volume*10**4/3875*18

ene = np.linspace(-8,3,251)

with ProcessPoolExecutor(max_workers=24) as executor:
    ohc = list(executor.map(orbi_conductance, ene))

for i in zip(ene,ohc):
    print(i[0],i[1])

